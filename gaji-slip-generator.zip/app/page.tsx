"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Calculator, Printer, RotateCcw, Save, Trash2, History, User, Wallet, CreditCard, Receipt } from "lucide-react"

interface FormData {
  namaKaryawan: string
  jabatan: string
  periodeBulan: number
  periodeTahun: number
  gajiPokok: number
  uangKehadiranPerHari: number
  jumlahHariKerja: number
  feeLemburPerHari: number
  jumlahHariLembur: number
  bonus: number
  potonganTerlambatPerHari: number
  jumlahHariTerlambat: number
  potonganTidakHadirPerHari: number
  jumlahHariTidakHadir: number
  bpjsKetenagakerjaan: number
  kasbon: number
}

interface SalaryResult {
  totalUangKehadiran: number
  totalLembur: number
  gajiKotor: number
  totalPotonganTerlambat: number
  totalPotonganTidakHadir: number
  totalPotongan: number
  gajiBersih: number
}

interface HistoryItem {
  id: string
  tanggal: string
  formData: FormData
  result: SalaryResult
}

const initialFormData: FormData = {
  namaKaryawan: "",
  jabatan: "",
  periodeBulan: new Date().getMonth() + 1,
  periodeTahun: new Date().getFullYear(),
  gajiPokok: 0,
  uangKehadiranPerHari: 0,
  jumlahHariKerja: 0,
  feeLemburPerHari: 0,
  jumlahHariLembur: 0,
  bonus: 0,
  potonganTerlambatPerHari: 0,
  jumlahHariTerlambat: 0,
  potonganTidakHadirPerHari: 0,
  jumlahHariTidakHadir: 0,
  bpjsKetenagakerjaan: 0,
  kasbon: 0,
}

const formatRupiah = (num: number): string => {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(num)
}

const parseRupiahInput = (value: string): number => {
  const numericValue = value.replace(/[^\d]/g, "")
  return parseInt(numericValue, 10) || 0
}

const BULAN_LIST = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember"
]

const formatPeriodeGaji = (bulan: number, tahun: number): string => {
  return `${BULAN_LIST[bulan - 1]} ${tahun}`
}

export default function SalaryCalculator() {
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [result, setResult] = useState<SalaryResult | null>(null)
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [showSlip, setShowSlip] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const slipRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const savedHistory = localStorage.getItem("salaryHistory")
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory))
    }
  }, [])

  const calculateSalary = useCallback((data: FormData): SalaryResult => {
    const totalUangKehadiran = data.uangKehadiranPerHari * data.jumlahHariKerja
    const totalLembur = data.feeLemburPerHari * data.jumlahHariLembur
    const gajiKotor = data.gajiPokok + totalUangKehadiran + totalLembur + data.bonus

    const totalPotonganTerlambat = data.potonganTerlambatPerHari * data.jumlahHariTerlambat
    const totalPotonganTidakHadir = data.potonganTidakHadirPerHari * data.jumlahHariTidakHadir
    const totalPotongan = totalPotonganTerlambat + totalPotonganTidakHadir + data.bpjsKetenagakerjaan + data.kasbon

    const gajiBersih = gajiKotor - totalPotongan

    return {
      totalUangKehadiran,
      totalLembur,
      gajiKotor,
      totalPotonganTerlambat,
      totalPotonganTidakHadir,
      totalPotongan,
      gajiBersih,
    }
  }, [])

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!formData.namaKaryawan.trim()) {
      newErrors.namaKaryawan = "Nama karyawan wajib diisi"
    }
    if (!formData.jabatan.trim()) {
      newErrors.jabatan = "Jabatan wajib diisi"
    }
    if (formData.periodeBulan < 1 || formData.periodeBulan > 12) {
      newErrors.periodeBulan = "Bulan tidak valid"
    }
    if (formData.periodeTahun < 2000 || formData.periodeTahun > 2100) {
      newErrors.periodeTahun = "Tahun tidak valid"
    }
    if (formData.gajiPokok <= 0) {
      newErrors.gajiPokok = "Gaji pokok harus lebih dari 0"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleInputChange = (field: keyof FormData, value: string | number) => {
    if (typeof value === "number" && value < 0) {
      value = 0
    }
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[field]
        return newErrors
      })
    }
  }

  const handleCurrencyInput = (field: keyof FormData, value: string) => {
    const numericValue = parseRupiahInput(value)
    handleInputChange(field, numericValue)
  }

  const handleCalculate = () => {
    if (!validateForm()) return

    const calculatedResult = calculateSalary(formData)
    setResult(calculatedResult)
    setShowSlip(true)

    // Save to history
    const newHistoryItem: HistoryItem = {
      id: Date.now().toString(),
      tanggal: new Date().toLocaleString("id-ID"),
      formData: { ...formData },
      result: calculatedResult,
    }

    const updatedHistory = [newHistoryItem, ...history]
    setHistory(updatedHistory)
    localStorage.setItem("salaryHistory", JSON.stringify(updatedHistory))
  }

  const handleReset = () => {
    setFormData(initialFormData)
    setResult(null)
    setShowSlip(false)
    setErrors({})
  }

  const handlePrint = () => {
    const printContent = slipRef.current
    if (!printContent) return

    const printWindow = window.open("", "_blank")
    if (!printWindow) return

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Slip Gaji - ${formData.namaKaryawan}</title>
          <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { 
              font-family: 'Poppins', sans-serif; 
              padding: 20px;
              background: white;
              color: #4a3f4f;
            }
            .slip-container {
              max-width: 210mm;
              margin: 0 auto;
              padding: 30px;
              border: 2px solid #f5a5b8;
              border-radius: 12px;
            }
            .header {
              text-align: center;
              margin-bottom: 30px;
              padding-bottom: 20px;
              border-bottom: 2px dashed #f5d4e0;
            }
            .header h1 {
              font-size: 24px;
              color: #f5a5b8;
              margin-bottom: 5px;
            }
            .header p {
              color: #7a6b80;
              font-size: 14px;
            }
            .section {
              margin-bottom: 25px;
            }
            .section-title {
              font-weight: 600;
              font-size: 14px;
              color: #f5a5b8;
              text-transform: uppercase;
              margin-bottom: 15px;
              padding-bottom: 8px;
              border-bottom: 1px solid #f5d4e0;
            }
            .row {
              display: flex;
              justify-content: space-between;
              padding: 8px 0;
              border-bottom: 1px dotted #f8e8ee;
            }
            .row:last-child {
              border-bottom: none;
            }
            .label {
              color: #7a6b80;
              font-size: 13px;
            }
            .value {
              font-weight: 500;
              font-size: 13px;
              color: #4a3f4f;
            }
            .total-row {
              background: #f8e8ee;
              padding: 12px;
              border-radius: 8px;
              margin-top: 10px;
            }
            .total-row .label,
            .total-row .value {
              font-weight: 600;
              font-size: 14px;
            }
            .thp-section {
              background: linear-gradient(135deg, #b8e8c8 0%, #7fc99a 100%);
              padding: 20px;
              border-radius: 12px;
              text-align: center;
              margin-top: 20px;
            }
            .thp-section .label {
              color: #2d5a3d;
              font-size: 14px;
              font-weight: 500;
            }
            .thp-section .value {
              color: #1a3d26;
              font-size: 28px;
              font-weight: 700;
              margin-top: 5px;
            }
            .footer {
              text-align: center;
              margin-top: 30px;
              padding-top: 20px;
              border-top: 2px dashed #f5d4e0;
              color: #7a6b80;
              font-size: 12px;
            }
            @media print {
              body { padding: 0; }
              .slip-container { border: none; }
            }
          </style>
        </head>
        <body>
          ${printContent.innerHTML}
        </body>
      </html>
    `)
    printWindow.document.close()
    printWindow.print()
  }

  const handleDeleteHistory = (id: string) => {
    const updatedHistory = history.filter((item) => item.id !== id)
    setHistory(updatedHistory)
    localStorage.setItem("salaryHistory", JSON.stringify(updatedHistory))
  }

  const handleClearHistory = () => {
    setHistory([])
    localStorage.removeItem("salaryHistory")
  }

  const handleLoadFromHistory = (item: HistoryItem) => {
    setFormData(item.formData)
    setResult(item.result)
    setShowSlip(true)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const CurrencyInput = ({
    value,
    onChange,
    placeholder,
    error,
  }: {
    value: number
    onChange: (value: string) => void
    placeholder: string
    error?: string
  }) => (
    <div>
      <input
        type="text"
        value={value > 0 ? formatRupiah(value).replace("Rp", "").trim() : ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#f5a5b8]/50 ${
          error
            ? "border-[#f87171] bg-red-50"
            : "border-[#f5d4e0] bg-[#fef0f5] hover:border-[#f5a5b8] focus:border-[#f5a5b8]"
        }`}
      />
      {error && <p className="text-[#f87171] text-sm mt-1">{error}</p>}
    </div>
  )

  const NumberInput = ({
    value,
    onChange,
    placeholder,
    error,
  }: {
    value: number
    onChange: (value: number) => void
    placeholder: string
    error?: string
  }) => (
    <div>
      <input
        type="number"
        min="0"
        value={value || ""}
        onChange={(e) => onChange(Math.max(0, parseInt(e.target.value) || 0))}
        placeholder={placeholder}
        className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#f5a5b8]/50 ${
          error
            ? "border-[#f87171] bg-red-50"
            : "border-[#f5d4e0] bg-[#fef0f5] hover:border-[#f5a5b8] focus:border-[#f5a5b8]"
        }`}
      />
      {error && <p className="text-[#f87171] text-sm mt-1">{error}</p>}
    </div>
  )

  return (
    <main className="min-h-screen bg-gradient-to-br from-[#fef6f9] via-[#fff5f0] to-[#f8f0ff] py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <header className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#f5a5b8] to-[#ffd4b8] rounded-2xl mb-4 shadow-lg">
            <Receipt className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-[#4a3f4f] mb-2">
            Slip Gaji Karyawan
          </h1>
          <p className="text-[#7a6b80]">Hitung dan cetak slip gaji dengan mudah</p>
        </header>

        {/* Form Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Data Karyawan */}
          <div className="bg-white rounded-2xl shadow-lg shadow-[#f5a5b8]/10 p-6 border border-[#f5d4e0]">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-[#f5a5b8] to-[#e89aad] rounded-xl flex items-center justify-center">
                <User className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-semibold text-[#4a3f4f]">Data Karyawan</h2>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#7a6b80] mb-2">Nama Karyawan *</label>
                <input
                  type="text"
                  value={formData.namaKaryawan}
                  onChange={(e) => handleInputChange("namaKaryawan", e.target.value)}
                  placeholder="Masukkan nama"
                  className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#f5a5b8]/50 ${
                    errors.namaKaryawan
                      ? "border-[#f87171] bg-red-50"
                      : "border-[#f5d4e0] bg-[#fef0f5] hover:border-[#f5a5b8] focus:border-[#f5a5b8]"
                  }`}
                />
                {errors.namaKaryawan && <p className="text-[#f87171] text-sm mt-1">{errors.namaKaryawan}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-[#7a6b80] mb-2">Jabatan *</label>
                <input
                  type="text"
                  value={formData.jabatan}
                  onChange={(e) => handleInputChange("jabatan", e.target.value)}
                  placeholder="Masukkan jabatan"
                  className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#f5a5b8]/50 ${
                    errors.jabatan
                      ? "border-[#f87171] bg-red-50"
                      : "border-[#f5d4e0] bg-[#fef0f5] hover:border-[#f5a5b8] focus:border-[#f5a5b8]"
                  }`}
                />
                {errors.jabatan && <p className="text-[#f87171] text-sm mt-1">{errors.jabatan}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-[#7a6b80] mb-2">Periode Gaji *</label>
                <div className="grid grid-cols-2 gap-3">
                  <select
                    value={formData.periodeBulan}
                    onChange={(e) => handleInputChange("periodeBulan", parseInt(e.target.value))}
                    className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#f5a5b8]/50 appearance-none bg-[#fef0f5] cursor-pointer ${
                      errors.periodeBulan
                        ? "border-[#f87171] bg-red-50"
                        : "border-[#f5d4e0] hover:border-[#f5a5b8] focus:border-[#f5a5b8]"
                    }`}
                  >
                    {BULAN_LIST.map((bulan, index) => (
                      <option key={index + 1} value={index + 1}>
                        {bulan}
                      </option>
                    ))}
                  </select>
                  <select
                    value={formData.periodeTahun}
                    onChange={(e) => handleInputChange("periodeTahun", parseInt(e.target.value))}
                    className={`w-full px-4 py-3 rounded-xl border-2 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#f5a5b8]/50 appearance-none bg-[#fef0f5] cursor-pointer ${
                      errors.periodeTahun
                        ? "border-[#f87171] bg-red-50"
                        : "border-[#f5d4e0] hover:border-[#f5a5b8] focus:border-[#f5a5b8]"
                    }`}
                  >
                    {Array.from({ length: 10 }, (_, i) => new Date().getFullYear() - 2 + i).map((tahun) => (
                      <option key={tahun} value={tahun}>
                        {tahun}
                      </option>
                    ))}
                  </select>
                </div>
                {(errors.periodeBulan || errors.periodeTahun) && (
                  <p className="text-[#f87171] text-sm mt-1">{errors.periodeBulan || errors.periodeTahun}</p>
                )}
              </div>
            </div>
          </div>

          {/* Komponen Pendapatan */}
          <div className="bg-white rounded-2xl shadow-lg shadow-[#ffd4b8]/10 p-6 border border-[#ffe4cc]">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-[#ffd4b8] to-[#f5b88a] rounded-xl flex items-center justify-center">
                <Wallet className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-semibold text-[#4a3f4f]">Komponen Pendapatan</h2>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#7a6b80] mb-2">Gaji Pokok *</label>
                <CurrencyInput
                  value={formData.gajiPokok}
                  onChange={(v) => handleCurrencyInput("gajiPokok", v)}
                  placeholder="0"
                  error={errors.gajiPokok}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Uang Kehadiran/Hari</label>
                  <CurrencyInput
                    value={formData.uangKehadiranPerHari}
                    onChange={(v) => handleCurrencyInput("uangKehadiranPerHari", v)}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Jumlah Hari Kerja</label>
                  <NumberInput
                    value={formData.jumlahHariKerja}
                    onChange={(v) => handleInputChange("jumlahHariKerja", v)}
                    placeholder="0"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Fee Lembur/Hari</label>
                  <CurrencyInput
                    value={formData.feeLemburPerHari}
                    onChange={(v) => handleCurrencyInput("feeLemburPerHari", v)}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Jumlah Hari Lembur</label>
                  <NumberInput
                    value={formData.jumlahHariLembur}
                    onChange={(v) => handleInputChange("jumlahHariLembur", v)}
                    placeholder="0"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#7a6b80] mb-2">Bonus</label>
                <CurrencyInput
                  value={formData.bonus}
                  onChange={(v) => handleCurrencyInput("bonus", v)}
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Komponen Potongan */}
          <div className="bg-white rounded-2xl shadow-lg shadow-[#e8d4f0]/20 p-6 border border-[#e8d4f0]">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-[#e8d4f0] to-[#d4b8e8] rounded-xl flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-semibold text-[#4a3f4f]">Komponen Potongan</h2>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Potongan Terlambat/Hari</label>
                  <CurrencyInput
                    value={formData.potonganTerlambatPerHari}
                    onChange={(v) => handleCurrencyInput("potonganTerlambatPerHari", v)}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Jumlah Hari Terlambat</label>
                  <NumberInput
                    value={formData.jumlahHariTerlambat}
                    onChange={(v) => handleInputChange("jumlahHariTerlambat", v)}
                    placeholder="0"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Potongan Tidak Hadir/Hari</label>
                  <CurrencyInput
                    value={formData.potonganTidakHadirPerHari}
                    onChange={(v) => handleCurrencyInput("potonganTidakHadirPerHari", v)}
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#7a6b80] mb-2">Jumlah Hari Tidak Hadir</label>
                  <NumberInput
                    value={formData.jumlahHariTidakHadir}
                    onChange={(v) => handleInputChange("jumlahHariTidakHadir", v)}
                    placeholder="0"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#7a6b80] mb-2">BPJS Ketenagakerjaan</label>
                <CurrencyInput
                  value={formData.bpjsKetenagakerjaan}
                  onChange={(v) => handleCurrencyInput("bpjsKetenagakerjaan", v)}
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#7a6b80] mb-2">Kasbon</label>
                <CurrencyInput
                  value={formData.kasbon}
                  onChange={(v) => handleCurrencyInput("kasbon", v)}
                  placeholder="0"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-10">
          <button
            onClick={handleCalculate}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#f5a5b8] to-[#ffd4b8] text-white font-semibold rounded-xl shadow-lg shadow-[#f5a5b8]/30 hover:shadow-xl hover:shadow-[#f5a5b8]/40 transition-all duration-200 hover:-translate-y-0.5"
          >
            <Calculator className="w-5 h-5" />
            Hitung Gaji
          </button>
          <button
            onClick={handleReset}
            className="inline-flex items-center gap-2 px-6 py-3 bg-white text-[#7a6b80] font-semibold rounded-xl border-2 border-[#f5d4e0] hover:bg-[#fef0f5] transition-all duration-200"
          >
            <RotateCcw className="w-5 h-5" />
            Reset
          </button>
          {showSlip && result && (
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#b8e8c8] to-[#7fc99a] text-white font-semibold rounded-xl shadow-lg shadow-[#b8e8c8]/30 hover:shadow-xl hover:shadow-[#b8e8c8]/40 transition-all duration-200 hover:-translate-y-0.5"
            >
              <Printer className="w-5 h-5" />
              Cetak Slip Gaji
            </button>
          )}
        </div>

        {/* Salary Slip Result */}
        {showSlip && result && (
          <div className="mb-10">
            <div ref={slipRef} className="slip-container bg-white rounded-2xl shadow-xl p-8 border border-[#f5d4e0] max-w-2xl mx-auto">
              <div className="header text-center mb-8 pb-6 border-b-2 border-dashed border-[#f5d4e0]">
                <h1 className="text-2xl font-bold text-[#f5a5b8] mb-1">SLIP GAJI KARYAWAN</h1>
                <p className="text-[#7a6b80] text-sm">Periode: {formatPeriodeGaji(formData.periodeBulan, formData.periodeTahun)}</p>
              </div>

              {/* Data Karyawan */}
              <div className="section mb-6">
                <h3 className="section-title font-semibold text-sm text-[#f5a5b8] uppercase mb-4 pb-2 border-b border-[#f5d4e0]">
                  Data Karyawan
                </h3>
                <div className="space-y-2">
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Nama Karyawan</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formData.namaKaryawan}</span>
                  </div>
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Jabatan</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formData.jabatan}</span>
                  </div>
                  <div className="row flex justify-between py-2">
                    <span className="label text-[#7a6b80] text-sm">Periode Gaji</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatPeriodeGaji(formData.periodeBulan, formData.periodeTahun)}</span>
                  </div>
                </div>
              </div>

              {/* Pendapatan */}
              <div className="section mb-6">
                <h3 className="section-title font-semibold text-sm text-[#ffd4b8] uppercase mb-4 pb-2 border-b border-[#ffe4cc]">
                  Pendapatan
                </h3>
                <div className="space-y-2">
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Gaji Pokok</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(formData.gajiPokok)}</span>
                  </div>
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Total Uang Kehadiran</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(result.totalUangKehadiran)}</span>
                  </div>
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Total Lembur</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(result.totalLembur)}</span>
                  </div>
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Bonus</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(formData.bonus)}</span>
                  </div>
                  <div className="total-row bg-[#fff5f0] p-3 rounded-lg mt-2">
                    <div className="flex justify-between">
                      <span className="label font-semibold text-sm text-[#4a3f4f]">Gaji Kotor</span>
                      <span className="value font-semibold text-sm text-[#4a3f4f]">{formatRupiah(result.gajiKotor)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Potongan */}
              <div className="section mb-6">
                <h3 className="section-title font-semibold text-sm text-[#e8d4f0] uppercase mb-4 pb-2 border-b border-[#e8d4f0]">
                  Potongan
                </h3>
                <div className="space-y-2">
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Total Potongan Terlambat</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(result.totalPotonganTerlambat)}</span>
                  </div>
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Total Potongan Tidak Hadir</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(result.totalPotonganTidakHadir)}</span>
                  </div>
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">BPJS Ketenagakerjaan</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(formData.bpjsKetenagakerjaan)}</span>
                  </div>
                  <div className="row flex justify-between py-2 border-b border-dotted border-[#f8e8ee]">
                    <span className="label text-[#7a6b80] text-sm">Kasbon</span>
                    <span className="value font-medium text-sm text-[#4a3f4f]">{formatRupiah(formData.kasbon)}</span>
                  </div>
                  <div className="total-row bg-[#f8f0ff] p-3 rounded-lg mt-2">
                    <div className="flex justify-between">
                      <span className="label font-semibold text-sm text-[#4a3f4f]">Total Potongan</span>
                      <span className="value font-semibold text-sm text-[#4a3f4f]">{formatRupiah(result.totalPotongan)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Take Home Pay */}
              <div className="thp-section bg-gradient-to-r from-[#b8e8c8] to-[#7fc99a] p-6 rounded-xl text-center">
                <p className="label text-[#2d5a3d] text-sm font-medium mb-1">TAKE HOME PAY (THP)</p>
                <p className="value text-[#1a3d26] text-3xl font-bold">{formatRupiah(result.gajiBersih)}</p>
              </div>

              <div className="footer text-center mt-8 pt-6 border-t-2 border-dashed border-[#f5d4e0] text-[#7a6b80] text-xs">
                <p>Slip gaji ini dicetak secara otomatis oleh sistem</p>
                <p className="mt-1">Tanggal cetak: {new Date().toLocaleString("id-ID")}</p>
              </div>
            </div>
          </div>
        )}

        {/* History Section */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-[#f5d4e0]">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#f5a5b8] to-[#e8d4f0] rounded-xl flex items-center justify-center">
                <History className="w-5 h-5 text-white" />
              </div>
              <h2 className="text-lg font-semibold text-[#4a3f4f]">Riwayat Perhitungan Gaji</h2>
            </div>
            {history.length > 0 && (
              <button
                onClick={handleClearHistory}
                className="inline-flex items-center gap-2 px-4 py-2 text-[#f87171] font-medium rounded-lg border-2 border-[#f87171]/30 hover:bg-[#f87171]/10 transition-all duration-200"
              >
                <Trash2 className="w-4 h-4" />
                Hapus Semua
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-[#f8e8ee] rounded-full flex items-center justify-center mx-auto mb-4">
                <Save className="w-8 h-8 text-[#f5a5b8]" />
              </div>
              <p className="text-[#7a6b80]">Belum ada riwayat perhitungan gaji</p>
              <p className="text-[#a99fb0] text-sm mt-1">Riwayat akan muncul setelah Anda menghitung gaji</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-[#f5d4e0]">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-[#7a6b80]">Tanggal</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-[#7a6b80]">Nama</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-[#7a6b80] hidden md:table-cell">Jabatan</th>
                    <th className="text-left py-3 px-4 text-sm font-semibold text-[#7a6b80] hidden lg:table-cell">Periode</th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-[#7a6b80] hidden sm:table-cell">Gaji Kotor</th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-[#7a6b80] hidden sm:table-cell">Potongan</th>
                    <th className="text-right py-3 px-4 text-sm font-semibold text-[#7a6b80]">Gaji Bersih</th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-[#7a6b80]">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((item) => (
                    <tr key={item.id} className="border-b border-[#f8e8ee] hover:bg-[#fef6f9] transition-colors">
                      <td className="py-3 px-4 text-sm text-[#4a3f4f]">{item.tanggal}</td>
                      <td className="py-3 px-4 text-sm text-[#4a3f4f] font-medium">{item.formData.namaKaryawan}</td>
                      <td className="py-3 px-4 text-sm text-[#7a6b80] hidden md:table-cell">{item.formData.jabatan}</td>
                      <td className="py-3 px-4 text-sm text-[#7a6b80] hidden lg:table-cell">{formatPeriodeGaji(item.formData.periodeBulan, item.formData.periodeTahun)}</td>
                      <td className="py-3 px-4 text-sm text-[#4a3f4f] text-right hidden sm:table-cell">{formatRupiah(item.result.gajiKotor)}</td>
                      <td className="py-3 px-4 text-sm text-[#f87171] text-right hidden sm:table-cell">-{formatRupiah(item.result.totalPotongan)}</td>
                      <td className="py-3 px-4 text-sm text-[#7fc99a] font-semibold text-right">{formatRupiah(item.result.gajiBersih)}</td>
                      <td className="py-3 px-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleLoadFromHistory(item)}
                            className="p-2 text-[#f5a5b8] hover:bg-[#f5a5b8]/10 rounded-lg transition-colors"
                            title="Lihat & Cetak"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteHistory(item.id)}
                            className="p-2 text-[#f87171] hover:bg-[#f87171]/10 rounded-lg transition-colors"
                            title="Hapus"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className="text-center mt-10 text-[#a99fb0] text-sm">
          <p>© 2026 Slip Gaji Karyawan. Dibuat dengan ❤️</p>
        </footer>
      </div>
    </main>
  )
}
